frontier= Queue()
    frontier.push(problem.getStartState())
    father={}
    father[problem.getStartState()]=[]
    actions={}
    path=[]
    expanded=set()
    while(frontier.isEmpty()==False):
        state=frontier.pop()
        if (problem.isGoalState(state)):
            while father[state]:
                path.insert(0,actions[state])
                state=father[state]
            return path
        else:
            if state not in expanded:
                expanded.add(state)
                for childstate,childactions,childcost in problem.getSuccessors(state):
                    if (childstate not in expanded) and (childstate not in father.keys()):
                        father[childstate]=state
                        actions[childstate]=childactions
                        frontier.push(childstate)



dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            for corner in self.corners:
                if(nextx,nexty)==corner:
                    state[1].append(corner)
            successors.append(((nextx,nexty),state[1]),action,self.getCostOfActions(action))


frontier= PriorityQueue()
    path=[]
    frontier.push((problem.getStartState(),None,0),heuristic(problem.getStartState(),problem))
    father={}
    father[problem.getStartState()]=None
    actions={}
    costs={}
    costs[problem.getStartState()]=0
    expanded=set()
    while(frontier.isEmpty()==False):
        node=frontier.pop()
        if (problem.isGoalState(node[0])):
            solution=node[0]
            break
        else:
            if node[0] not in expanded:
                expanded.add(node[0])
                for childnode in problem.getSuccessors(node[0]):
                    if (childnode[0] not in expanded) : 
                        priority=node[2]+childnode[2]+heuristic(childnode[0],problem)
                        if childnode[0] in costs.keys():
                            if costs[childnode[0]]<=priority:
                                continue
                        frontier.push((childnode[0],childnode[1],childnode[2]+node[2]),priority)
                        costs[childnode[0]]=priority
                        father[childnode[0]]=node[0]
                        actions[childnode[0]]=childnode[1]
    while father[solution]:
        path.insert(0,actions[solution])
        solution=father[solution]
    return path